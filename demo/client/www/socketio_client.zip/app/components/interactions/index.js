(function () {
  'use strict';

  angular.module('xyz.socket.chat.interactions', [
    'xyz.socket.chat.interactions.keyboard'
  ]);

})();
