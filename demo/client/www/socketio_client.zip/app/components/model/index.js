(function () {
  'use strict';

  angular.module('xyz.socket.chat.models', [
    'globals',
    'xyz.socket.chat.services.localStorage'
  ]);

})();
