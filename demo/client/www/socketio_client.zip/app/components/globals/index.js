(function () {
  'use strict';
  angular.module('globals', [
    'globals.lodash'
  ]);

})();
