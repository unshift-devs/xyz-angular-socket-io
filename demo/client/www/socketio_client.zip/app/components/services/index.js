(function () {
  'use strict';

  angular.module('xyz.socket.chat.services', [
    'xyz.socket.chat.services.localStorage',
    'xyz.socket.chat.services.rest'
  ]);

})();
