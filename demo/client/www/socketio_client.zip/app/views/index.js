(function () {
  'use strict';

  angular.module('xyz.socket.chat.views', [
    'globals',
    'xyz.socket.chat.interactions.keyboard',
    'xyz.socket',
    'xyz.socket.chat.config',
    'xyz.socket.chat.services.rest'
  ]);

})();
