angular.module('xyz.socket.chat.env', [])
.constant('socketUrl', "http://localhost:5400")
.constant('restBaseUrl', "http://localhost:5400");
